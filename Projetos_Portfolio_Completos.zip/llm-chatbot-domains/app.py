import streamlit as st
from utils.inference import gerar_resposta

st.title("Chatbot de Filmes com LLM")
pergunta = st.text_input("Pergunte algo sobre filmes:")

if st.button("Enviar"):
    resposta = gerar_resposta(pergunta)
    st.write(resposta)
