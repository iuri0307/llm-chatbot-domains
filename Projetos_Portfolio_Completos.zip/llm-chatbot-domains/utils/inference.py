from transformers import pipeline

def gerar_resposta(pergunta):
    generator = pipeline("text-generation", model="EleutherAI/gpt-neo-1.3B")
    resposta = generator(pergunta, max_length=100, do_sample=True)[0]['generated_text']
    return resposta
