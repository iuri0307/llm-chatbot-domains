# ChatBot com LLM (Filmes)

ChatBot interativo com LLM do HuggingFace para responder perguntas sobre filmes.

## Como rodar

```bash
pip install -r requirements.txt
streamlit run app.py
```