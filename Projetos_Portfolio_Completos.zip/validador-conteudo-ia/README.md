# Validador de Conteúdo Gerado por IA

Este script analisa textos gerados por LLMs, identificando erros gramaticais e analisando entidades nomeadas.