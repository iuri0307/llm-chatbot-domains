import spacy
import language_tool_python

def validar_texto(texto):
    tool = language_tool_python.LanguageTool('en-US')
    erros = tool.check(texto)
    print(f"Total de erros encontrados: {len(erros)}")
    for e in erros[:5]:
        print(f"- {e.message}")

    nlp = spacy.load("en_core_web_sm")
    doc = nlp(texto)
    print("\nEntidades encontradas:")
    for ent in doc.ents:
        print(f"{ent.text} -> {ent.label_}")

if __name__ == "__main__":
    with open("examples/textos_gerados.txt", "r") as f:
        texto = f.read()
    validar_texto(texto)
