# Dashboard SQL

Dashboard simples que lê dados de um banco SQLite e gera gráficos com Streamlit.