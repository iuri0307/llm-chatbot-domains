import streamlit as st
import pandas as pd
from sqlalchemy import create_engine

st.title("Dashboard de Vendas")

engine = create_engine('sqlite:///data/banco.db')
query = "SELECT * FROM vendas"
df = pd.read_sql(query, engine)

st.dataframe(df)

st.bar_chart(df.groupby('categoria')['total'].sum())
