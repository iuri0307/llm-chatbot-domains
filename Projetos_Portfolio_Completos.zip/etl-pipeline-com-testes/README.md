# ETL com Testes

Pipeline simples com extração de CSV, transformação e carga em SQLite, com testes usando Pytest.