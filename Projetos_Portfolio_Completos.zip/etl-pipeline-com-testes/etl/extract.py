import pandas as pd

def extract(path):
    return pd.read_csv(path)
