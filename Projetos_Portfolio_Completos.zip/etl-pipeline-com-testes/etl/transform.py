def transform(df):
    df.columns = [col.lower().strip() for col in df.columns]
    return df.dropna()
