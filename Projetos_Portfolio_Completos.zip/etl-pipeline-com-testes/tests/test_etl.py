from etl.extract import extract
from etl.transform import transform

def test_extraction():
    df = extract("data/dados.csv")
    assert not df.empty

def test_transformation():
    df = extract("data/dados.csv")
    df_trans = transform(df)
    assert df_trans.isnull().sum().sum() == 0
